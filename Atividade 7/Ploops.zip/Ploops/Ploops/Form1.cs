﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ploops
{
    public partial class PLoops : Form
    {
        public PLoops()
        {
            InitializeComponent();
        }

        private void exercicio1ToolStripMenuItem_Click(object sender, EventArgs e)
        {


            if (Application.OpenForms.OfType<FrmExercicio1>().Count() > 0)
            {
                // se o formulário não tiver nenhum componente dá erro
                // precisaria testar o controls.Count do form
                Application.OpenForms["frmExercicio1"].BringToFront();
            }
            else
            {
                FrmExercicio1 frm1 = new FrmExercicio1();
                frm1.MdiParent = this;
                frm1.WindowState = FormWindowState.Maximized;
                frm1.Show();
            }

        }

        private void exercicio2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio2>().Count() > 0)
            {
                // se o formulário não tiver nenhum componente dá erro
                // precisaria testar o controls.Count do form
                Application.OpenForms["frmExercicio2"].BringToFront();
            }
            else
            {
                FrmExercicio2 frm2 = new FrmExercicio2();
                frm2.MdiParent = this;
                frm2.WindowState = FormWindowState.Maximized;
                frm2.Show();
            }
        }

        private void exercicio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio3>().Count() > 0)
            {
                // se o formulário não tiver nenhum componente dá erro
                // precisaria testar o controls.Count do form
                Application.OpenForms["frmExercicio3"].BringToFront();
            }
            else
            {
                FrmExercicio3 frm3 = new FrmExercicio3();
                frm3.MdiParent = this;
                frm3.WindowState = FormWindowState.Maximized;
                frm3.Show();
            }
        }

        private void exercicio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio1>().Count() > 0)
            {
                // se o formulário não tiver nenhum componente dá erro
                // precisaria testar o controls.Count do form
                Application.OpenForms["frmExercicio1"].BringToFront();
            }
            else
            {
                FrmExercicio1 frm1 = new FrmExercicio1();
                frm1.MdiParent = this;
                frm1.WindowState = FormWindowState.Maximized;
                frm1.Show();
            }
        }
    }
}
