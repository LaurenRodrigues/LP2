﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ploops
{
    public partial class FrmExercicio1 : Form
    {
        public FrmExercicio1()
        {
            InitializeComponent();
        }
        int TextoBranco = 0, TextoR = 0, TextoPar = 0;

        private void button2_Click(object sender, EventArgs e)
        {

            string texto = RichTextBoxEx1.Text;

            if (string.IsNullOrEmpty(texto))
            {
                MessageBox.Show("Caixa de Texto vazia");
            }
            else
            {
                var pares = new Dictionary<string, int>();

                for (int i = 0; i < texto.Length - 1; i++) // Verifica até o penúltimo caractere
                {
                    string par = $"{texto[i]}{texto[i + 1]}"; // Cria o par de letras
                    if (texto[i + 1] != ' ' && texto[i] != ' ')
                    {
                        if (pares.ContainsKey(par))
                        {
                            pares[par]++;
                        }
                        else
                        {
                            pares[par] = 0;
                        }
                    }
                }

                // Exibe os resultados
                foreach (var item in pares)
                {
                    MessageBox.Show($"Há {item.Value} pares de '{item.Key}' em seu texto");
                }
               
                
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string texto = RichTextBoxEx1.Text;

            if (texto == string.Empty)
            {
                MessageBox.Show("Caixa de Texto vazia");
            }
            else
            {

                for (int i = 0; i < texto.Length; i++)
                {
                    if (texto[i] == ' ')
                    {
                        TextoBranco++;
                    }
                }
                if (TextoBranco > 0)
                {
                    MessageBox.Show($"Há {TextoBranco} espaços em branco no texto");
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string texto = RichTextBoxEx1.Text;

            if (texto == string.Empty)
            {
                MessageBox.Show("Caixa de Texto vazia");
            }
            else
            {

                for (int i = 0; i < texto.Length; i++)
                {
                    if (texto[i] == 'r' || texto[i] == 'R')
                    {
                        TextoR++;
                    }
                }
                if (TextoR > 0)
                {
                    MessageBox.Show($"Há {TextoR} digitos R no texto");
                }
            }
        }

    }
}
