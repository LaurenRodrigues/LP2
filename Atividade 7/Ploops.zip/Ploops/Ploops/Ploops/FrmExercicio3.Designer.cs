﻿namespace Ploops
{
    partial class FrmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.TxtBoxEx3 = new System.Windows.Forms.TextBox();
            this.BtnTeste = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Forte", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(137)))), ((int)(((byte)(84)))), ((int)(((byte)(60)))));
            this.label1.Location = new System.Drawing.Point(314, 90);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(254, 38);
            this.label1.TabIndex = 0;
            this.label1.Text = "É Palindromo?";
            // 
            // TxtBoxEx3
            // 
            this.TxtBoxEx3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(247)))));
            this.TxtBoxEx3.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F);
            this.TxtBoxEx3.ForeColor = System.Drawing.Color.Sienna;
            this.TxtBoxEx3.Location = new System.Drawing.Point(145, 157);
            this.TxtBoxEx3.MaxLength = 50;
            this.TxtBoxEx3.Name = "TxtBoxEx3";
            this.TxtBoxEx3.Size = new System.Drawing.Size(597, 47);
            this.TxtBoxEx3.TabIndex = 1;
            // 
            // BtnTeste
            // 
            this.BtnTeste.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(137)))), ((int)(((byte)(84)))), ((int)(((byte)(60)))));
            this.BtnTeste.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnTeste.Font = new System.Drawing.Font("Forte", 26.25F, System.Drawing.FontStyle.Bold);
            this.BtnTeste.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(247)))));
            this.BtnTeste.Location = new System.Drawing.Point(321, 386);
            this.BtnTeste.Name = "BtnTeste";
            this.BtnTeste.Size = new System.Drawing.Size(247, 119);
            this.BtnTeste.TabIndex = 2;
            this.BtnTeste.Text = "Testar";
            this.BtnTeste.UseVisualStyleBackColor = false;
            this.BtnTeste.Click += new System.EventHandler(this.button1_Click);
            // 
            // FrmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Ploops.Properties.Resources.Design_sem_nome;
            this.ClientSize = new System.Drawing.Size(917, 622);
            this.Controls.Add(this.BtnTeste);
            this.Controls.Add(this.TxtBoxEx3);
            this.Controls.Add(this.label1);
            this.Name = "FrmExercicio3";
            this.Text = "FrmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TxtBoxEx3;
        private System.Windows.Forms.Button BtnTeste;
    }
}