﻿using System;
using System.Windows.Forms;

namespace Ploops
{
    public partial class FrmExercicio4 : Form
    {
        public FrmExercicio4()
        {
            InitializeComponent();
        }

        Double producao, salario, gratificacao, SalarioBruto;
        private void Salario_Validated(object sender, EventArgs e)
        {
            try
            {
                salario = Convert.ToDouble(Salario.Text); // testa se é um valor numérico
            }
            catch
            {
                MessageBox.Show("Insira um valor numérico válido");
                Focus();
                Events.Equals(false);
            }
        }



        private void textBox6_Validated(object sender, EventArgs e)
        {
            try
            {
                gratificacao = Convert.ToDouble(TxtGratificacao.Text); // testa se é um valor numérico
            }
            catch
            {
                MessageBox.Show("Insira um valor numérico válido");
                Focus();
                Events.Equals(false);
            }
        }


        private void Producao_Validated(object sender, EventArgs e)
        {
            try
            {
                producao = Convert.ToDouble(Producao.Text); // testa se é um valor numérico
            }
            catch
            {
                MessageBox.Show("Insira um valor numérico válido");
                Focus();
                Events.Equals(false);
            }


        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            double A;
            int B = 0, C = 0, D = 0;
            producao = Convert.ToDouble(Producao.Text);
            A = Convert.ToDouble(Salario.Text);
            gratificacao = Convert.ToDouble(TxtGratificacao.Text);
            if (producao >= 100)
                B = 1;
            if (producao >= 120)
                C = 1;
            if (producao >= 150)
                D = 1;
            SalarioBruto = A + A * (0.05 * B + 0.1 * C + 0.1 * D) + gratificacao;
            SalBruto.Text = SalarioBruto.ToString();
        }
    }
}
