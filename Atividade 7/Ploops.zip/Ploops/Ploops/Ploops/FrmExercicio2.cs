﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ploops
{
    public partial class FrmExercicio2 : Form
    {
        public FrmExercicio2()
        {
            InitializeComponent();
            
        }

        double n, h = 0;

        private void textBox1_Validated(object sender, EventArgs e)
        {
            try
            {
                n = Double.Parse(textBox1.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Não é um número real, insira valor");
                Focus();
                Events.Equals(false);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            n = double.Parse(textBox1.Text);
            for (float i = 1; i <= n; i++)
            {
                h += 1 / i;
            }
            textBox2.Text = Convert.ToString(h);
        }
    }
}
