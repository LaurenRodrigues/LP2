﻿namespace Ploops
{
    partial class FrmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Nome = new System.Windows.Forms.TextBox();
            this.Matricula = new System.Windows.Forms.TextBox();
            this.Producao = new System.Windows.Forms.TextBox();
            this.Salario = new System.Windows.Forms.TextBox();
            this.SalBruto = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.TxtGratificacao = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.BtnCalcular = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Nome
            // 
            this.Nome.BackColor = System.Drawing.Color.White;
            this.Nome.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Nome.Font = new System.Drawing.Font("Sitka Heading", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nome.ForeColor = System.Drawing.Color.SaddleBrown;
            this.Nome.Location = new System.Drawing.Point(478, 102);
            this.Nome.Name = "Nome";
            this.Nome.Size = new System.Drawing.Size(374, 44);
            this.Nome.TabIndex = 0;
            // 
            // Matricula
            // 
            this.Matricula.BackColor = System.Drawing.Color.White;
            this.Matricula.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Matricula.Font = new System.Drawing.Font("Sitka Heading", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Matricula.ForeColor = System.Drawing.Color.SaddleBrown;
            this.Matricula.Location = new System.Drawing.Point(478, 165);
            this.Matricula.Name = "Matricula";
            this.Matricula.Size = new System.Drawing.Size(374, 44);
            this.Matricula.TabIndex = 1;
            // 
            // Producao
            // 
            this.Producao.BackColor = System.Drawing.Color.White;
            this.Producao.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Producao.Font = new System.Drawing.Font("Sitka Heading", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Producao.ForeColor = System.Drawing.Color.SaddleBrown;
            this.Producao.Location = new System.Drawing.Point(478, 225);
            this.Producao.Name = "Producao";
            this.Producao.Size = new System.Drawing.Size(374, 44);
            this.Producao.TabIndex = 2;
            this.Producao.Validated += new System.EventHandler(this.Producao_Validated);
            // 
            // Salario
            // 
            this.Salario.BackColor = System.Drawing.Color.White;
            this.Salario.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Salario.Font = new System.Drawing.Font("Sitka Heading", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Salario.ForeColor = System.Drawing.Color.SaddleBrown;
            this.Salario.Location = new System.Drawing.Point(478, 287);
            this.Salario.Name = "Salario";
            this.Salario.Size = new System.Drawing.Size(374, 44);
            this.Salario.TabIndex = 3;
            this.Salario.Validated += new System.EventHandler(this.Salario_Validated);
            // 
            // SalBruto
            // 
            this.SalBruto.BackColor = System.Drawing.Color.White;
            this.SalBruto.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SalBruto.Font = new System.Drawing.Font("Sitka Heading", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SalBruto.ForeColor = System.Drawing.Color.SaddleBrown;
            this.SalBruto.Location = new System.Drawing.Point(396, 545);
            this.SalBruto.Name = "SalBruto";
            this.SalBruto.ReadOnly = true;
            this.SalBruto.Size = new System.Drawing.Size(374, 44);
            this.SalBruto.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.label1.Font = new System.Drawing.Font("Sitka Heading", 26.25F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Sienna;
            this.label1.Location = new System.Drawing.Point(64, 102);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 50);
            this.label1.TabIndex = 5;
            this.label1.Text = "Nome :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(246)))), ((int)(((byte)(211)))));
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("Sitka Heading", 26.25F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Sienna;
            this.label2.Location = new System.Drawing.Point(54, 165);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(201, 50);
            this.label2.TabIndex = 6;
            this.label2.Text = "Matricula  :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(246)))), ((int)(((byte)(211)))));
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Font = new System.Drawing.Font("Sitka Heading", 26.25F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.Sienna;
            this.label3.Location = new System.Drawing.Point(54, 225);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(185, 50);
            this.label3.TabIndex = 7;
            this.label3.Text = "Produção :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(246)))), ((int)(((byte)(211)))));
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Font = new System.Drawing.Font("Sitka Heading", 26.25F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.Sienna;
            this.label4.Location = new System.Drawing.Point(54, 287);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(151, 50);
            this.label4.TabIndex = 8;
            this.label4.Text = "Salário :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(246)))), ((int)(((byte)(211)))));
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Font = new System.Drawing.Font("Sitka Heading", 26.25F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.Sienna;
            this.label5.Location = new System.Drawing.Point(54, 346);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(219, 50);
            this.label5.TabIndex = 10;
            this.label5.Text = "Gratificação:";
            // 
            // TxtGratificacao
            // 
            this.TxtGratificacao.BackColor = System.Drawing.Color.White;
            this.TxtGratificacao.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtGratificacao.Font = new System.Drawing.Font("Sitka Heading", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtGratificacao.ForeColor = System.Drawing.Color.SaddleBrown;
            this.TxtGratificacao.Location = new System.Drawing.Point(478, 346);
            this.TxtGratificacao.Name = "TxtGratificacao";
            this.TxtGratificacao.Size = new System.Drawing.Size(374, 44);
            this.TxtGratificacao.TabIndex = 9;
            this.TxtGratificacao.Validated += new System.EventHandler(this.textBox6_Validated);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.label6.Font = new System.Drawing.Font("Sitka Heading", 26.25F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.IndianRed;
            this.label6.Location = new System.Drawing.Point(106, 539);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(238, 50);
            this.label6.TabIndex = 11;
            this.label6.Text = "Salário Bruto:";
            // 
            // BtnCalcular
            // 
            this.BtnCalcular.BackColor = System.Drawing.Color.MistyRose;
            this.BtnCalcular.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnCalcular.Font = new System.Drawing.Font("Sitka Heading", 26.25F, System.Drawing.FontStyle.Bold);
            this.BtnCalcular.ForeColor = System.Drawing.Color.IndianRed;
            this.BtnCalcular.Location = new System.Drawing.Point(309, 418);
            this.BtnCalcular.Name = "BtnCalcular";
            this.BtnCalcular.Size = new System.Drawing.Size(238, 91);
            this.BtnCalcular.TabIndex = 12;
            this.BtnCalcular.Text = "Calcular";
            this.BtnCalcular.UseVisualStyleBackColor = false;
            this.BtnCalcular.Click += new System.EventHandler(this.BtnCalcular_Click);
            // 
            // FrmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(246)))), ((int)(((byte)(211)))));
            this.BackgroundImage = global::Ploops.Properties.Resources.Inserir_um_pouquinho_de_texto;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(908, 634);
            this.Controls.Add(this.BtnCalcular);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.TxtGratificacao);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SalBruto);
            this.Controls.Add(this.Salario);
            this.Controls.Add(this.Producao);
            this.Controls.Add(this.Matricula);
            this.Controls.Add(this.Nome);
            this.Name = "FrmExercicio4";
            this.Text = "FrmExercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Nome;
        private System.Windows.Forms.TextBox Matricula;
        private System.Windows.Forms.TextBox Producao;
        private System.Windows.Forms.TextBox Salario;
        private System.Windows.Forms.TextBox SalBruto;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox TxtGratificacao;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button BtnCalcular;
    }
}