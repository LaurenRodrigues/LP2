﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ploops
{
    public partial class FrmExercicio3 : Form
    {
        public FrmExercicio3()
        {
            InitializeComponent();
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            string Teste, Frase;
            Frase = TxtBoxEx3.Text;
           
            Frase = Frase.Replace(" ", ""); // tira os espaços
           
            char[] caracteres = Frase.ToCharArray(); // faz um array com os caracteres de frase
            Array.Reverse(caracteres); // inverte o array
            Teste = new string(caracteres); // variavel string teste recebe os dados do array invertido de frase
            
            Teste.ToUpper();
            Frase.ToUpper(); // deixa todos os caracteres em caixa alta

            int n = 0; // contador de caracteres iguais

            for (int i = 0; i < caracteres.Length; i++)
            {

                if (Teste[i] == Frase[i])
                    n++;
            }
            if (n == Frase.Length) //Se a quantidade de caracteres iguais for a mesma da quantidade de caracteres de frase
                MessageBox.Show("é palindromo"); 
            else
                MessageBox.Show("não é palindromo");

        }
    }
}
