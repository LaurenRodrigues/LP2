﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalc
{
    public partial class Form1 : Form
    {
        double num1, num2, resultado;

        private void TxtNum1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(TxtNum1.Text, out num1)) // Verifica se a conversão para double funcionou 
            {
                // MessageBox.Show("Número Inválido!");
                errorProvider1.SetError(TxtNum1, "Número inválido");
                TxtNum1.Focus();
            }
            else
            {
                errorProvider1.SetError(TxtNum1, string.Empty);
            }

        }

        private void TxtNum2_Validated(object sender, EventArgs e)
        {
            try
            {   
                errorProvider2.SetError(TxtNum2,string.Empty);
                num2 = Convert.ToDouble(TxtNum2.Text);
            }
            catch (Exception ex)
            {
                // MessageBox.Show("Número inválido!\n" + ex.Message); // Se ocorreu erro, avisa o usuário e mostra a mensagem de erro
                errorProvider2.SetError(TxtNum2, "Número 2 inválido");
               TxtNum2.Focus();
            }
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            {
                resultado = num1 + num2;
                TxtResult.Text = resultado.ToString();
            }
        }

        private void BtnSub_Click(object sender, EventArgs e)
        {
            {
                resultado = num1 + num2;
                TxtResult.Text = resultado.ToString();
            }
        }

        private void BtnMult_Click(object sender, EventArgs e)
        {
            {
                resultado = num1 * num2;
                TxtResult.Text = resultado.ToString();
            }

        }

        private void BtnDiv_Click(object sender, EventArgs e)
        {
            if (num2 == 0)
            {
                MessageBox.Show("Divisão por zero não existe!", "Erro!", MessageBoxButtons.OK, MessageBoxIcon.Error); // TEXTO, TÍTULO, BOTÃO, ICONE 
                TxtNum2.Text = "";
                TxtNum2.Focus();
            }
            else
            {
                resultado = num1 / num2;
                TxtResult.Text = resultado.ToString();
            }
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?", "Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question)==DialogResult.Yes)
            {
                Close   ();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            TxtNum1.Clear();
            TxtNum2.Clear();
            TxtResult.Clear();
        }
    }
}
