using Microsoft.VisualBasic;
using System.Diagnostics;

namespace PVolume
{
    [DebuggerDisplay($"{{{nameof(GetDebuggerDisplay)}(),nq}}")]
    public partial class Form1 : Form
    {
        Double raio, altura, volume;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtRaio.Text, out raio))
            {
                MessageBox.Show("Raio inv�lido");
                txtRaio.Focus();
            }
            else
            {
                if (raio <= 0)
                {
                    MessageBox.Show("O raio deve ser um valor positivo");
                    txtRaio.Focus();
                }
            }
        }

        private string GetDebuggerDisplay()
        {
            return ToString();
        }

        private void txtAltura_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!Double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Altura inv�lida");
                e.Cancel = true;

            }
            else
            {
                if (altura <= 0)
                {
                    MessageBox.Show("A altura deve ser um valor positivo");
                    e.Cancel = true;
                }
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            volume = Math.PI * Math.Pow(raio, 2) * altura;
            txtVolume.Text = volume.ToString("N2");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtRaio.Clear();
            txtVolume.Clear();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
