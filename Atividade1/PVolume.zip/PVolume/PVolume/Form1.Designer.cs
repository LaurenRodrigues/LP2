﻿namespace PVolume
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnFechar = new Button();
            btnLimpar = new Button();
            btnCalcular = new Button();
            Raio = new Label();
            Altura = new Label();
            Volume = new Label();
            txtVolume = new TextBox();
            txtAltura = new TextBox();
            txtRaio = new TextBox();
            SuspendLayout();
            // 
            // btnFechar
            // 
            btnFechar.Location = new Point(758, 664);
            btnFechar.Name = "btnFechar";
            btnFechar.Size = new Size(182, 90);
            btnFechar.TabIndex = 0;
            btnFechar.Text = "Fechar";
            btnFechar.UseVisualStyleBackColor = true;
            btnFechar.Click += btnFechar_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(426, 664);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(182, 90);
            btnLimpar.TabIndex = 1;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(82, 664);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(182, 90);
            btnCalcular.TabIndex = 2;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // Raio
            // 
            Raio.AutoSize = true;
            Raio.Font = new Font("Segoe UI", 18F);
            Raio.Location = new Point(187, 76);
            Raio.Name = "Raio";
            Raio.Size = new Size(60, 32);
            Raio.TabIndex = 3;
            Raio.Text = "Raio";
            // 
            // Altura
            // 
            Altura.AutoSize = true;
            Altura.Font = new Font("Segoe UI", 18F);
            Altura.Location = new Point(187, 297);
            Altura.Name = "Altura";
            Altura.Size = new Size(77, 32);
            Altura.TabIndex = 4;
            Altura.Text = "Altura";
            // 
            // Volume
            // 
            Volume.AutoSize = true;
            Volume.Font = new Font("Segoe UI", 18F);
            Volume.Location = new Point(187, 527);
            Volume.Name = "Volume";
            Volume.Size = new Size(95, 32);
            Volume.TabIndex = 5;
            Volume.Text = "Volume";
            // 
            // txtVolume
            // 
            txtVolume.Enabled = false;
            txtVolume.Font = new Font("Segoe UI", 18F);
            txtVolume.Location = new Point(309, 524);
            txtVolume.Name = "txtVolume";
            txtVolume.Size = new Size(369, 39);
            txtVolume.TabIndex = 6;
            // 
            // txtAltura
            // 
            txtAltura.Font = new Font("Segoe UI", 18F);
            txtAltura.Location = new Point(309, 294);
            txtAltura.Name = "txtAltura";
            txtAltura.Size = new Size(369, 39);
            txtAltura.TabIndex = 7;
            txtAltura.Validating += txtAltura_Validating;
            // 
            // txtRaio
            // 
            txtRaio.Font = new Font("Segoe UI", 18F);
            txtRaio.Location = new Point(309, 73);
            txtRaio.Name = "txtRaio";
            txtRaio.Size = new Size(369, 39);
            txtRaio.TabIndex = 8;
            txtRaio.Validated += txtRaio_Validated;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1016, 838);
            Controls.Add(txtRaio);
            Controls.Add(txtAltura);
            Controls.Add(txtVolume);
            Controls.Add(Volume);
            Controls.Add(Altura);
            Controls.Add(Raio);
            Controls.Add(btnCalcular);
            Controls.Add(btnLimpar);
            Controls.Add(btnFechar);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnFechar;
        private Button btnLimpar;
        private Button btnCalcular;
        private Label Raio;
        private Label Altura;
        private Label Volume;
        private TextBox txtVolume;
        private TextBox txtAltura;
        private TextBox txtRaio;
    }
}
