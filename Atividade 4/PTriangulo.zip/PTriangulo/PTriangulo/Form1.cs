﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Double A, B, C;
        private void LimparBtn_Click(object sender, EventArgs e)
        {
            txtLadoA.Text = null;
            txtLadoB.Text = null;
            txtLadoC.Text = null;


        }

        private void txtLadoB_Validating(object sender, CancelEventArgs e)
        {
            try
            {
                B = Convert.ToDouble(txtLadoB.Text);
            }
            catch 
            {
                MessageBox.Show("Complete o campo B com um valor numérico");
                txtLadoB.Text = null;
                e.Cancel = true;
            }
        }

        private void txtLadoC_Validating(object sender, CancelEventArgs e)
        {
            {
                try
                {
                    C = Convert.ToDouble(txtLadoC.Text);
                }
                catch
                {
                    MessageBox.Show("Complete o campo C com um valor numérico");
                    txtLadoC.Text = null;
                    e.Cancel = true;
                }
                
            }
        }

        private void VerificarBtn_Click(object sender, EventArgs e)
        {
           
            if ((A<B+C) && (A>Math.Abs(B-C)) && (B>Math.Abs(A-C)) && (B<A+C) && (C>Math.Abs(A-B)) && (C<A+B))
                {
                if (A == B && B == C)
                {
                    MessageBox.Show("Triangulo Equilátero");
                }
                else if ((A==B && B!=C)|| (A==C && B!=A) || (B == C && C!=A))
                {
                    MessageBox.Show("Triangulo Isósceles");
                }
                else if (A!= B && B!=C)
                {
                    MessageBox.Show("Triangulo Escaleno");
                }
            }
            else
            {
                MessageBox.Show("Os valores não formam um triângulo");
            }
        }

        private void SairBtn_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtLadoA_Validating(object sender, CancelEventArgs e)
        {
            try
            { 
               A = Convert.ToDouble(txtLadoA.Text);
            }
            catch 
            {
                MessageBox.Show("Complete o campo A com um valor numérico");
                txtLadoA.Text = null;
                e.Cancel = true;
            }
        }
    }
}
