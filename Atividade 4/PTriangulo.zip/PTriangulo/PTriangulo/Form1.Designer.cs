﻿namespace PTriangulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblLadoA = new System.Windows.Forms.Label();
            this.LblLadoB = new System.Windows.Forms.Label();
            this.LblLadoC = new System.Windows.Forms.Label();
            this.SairBtn = new System.Windows.Forms.Button();
            this.LimparBtn = new System.Windows.Forms.Button();
            this.VerificarBtn = new System.Windows.Forms.Button();
            this.txtLadoC = new System.Windows.Forms.TextBox();
            this.txtLadoB = new System.Windows.Forms.TextBox();
            this.txtLadoA = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // LblLadoA
            // 
            this.LblLadoA.AutoSize = true;
            this.LblLadoA.Font = new System.Drawing.Font("Script MT Bold", 28F, System.Drawing.FontStyle.Bold);
            this.LblLadoA.Location = new System.Drawing.Point(90, 134);
            this.LblLadoA.Name = "LblLadoA";
            this.LblLadoA.Size = new System.Drawing.Size(137, 46);
            this.LblLadoA.TabIndex = 0;
            this.LblLadoA.Text = "Lado A";
            // 
            // LblLadoB
            // 
            this.LblLadoB.AutoSize = true;
            this.LblLadoB.Font = new System.Drawing.Font("Script MT Bold", 28F, System.Drawing.FontStyle.Bold);
            this.LblLadoB.Location = new System.Drawing.Point(87, 232);
            this.LblLadoB.Name = "LblLadoB";
            this.LblLadoB.Size = new System.Drawing.Size(140, 46);
            this.LblLadoB.TabIndex = 1;
            this.LblLadoB.Text = "Lado B";
            // 
            // LblLadoC
            // 
            this.LblLadoC.AutoSize = true;
            this.LblLadoC.Font = new System.Drawing.Font("Script MT Bold", 28F, System.Drawing.FontStyle.Bold);
            this.LblLadoC.Location = new System.Drawing.Point(95, 325);
            this.LblLadoC.Name = "LblLadoC";
            this.LblLadoC.Size = new System.Drawing.Size(132, 46);
            this.LblLadoC.TabIndex = 2;
            this.LblLadoC.Text = "Lado C";
            // 
            // SairBtn
            // 
            this.SairBtn.Font = new System.Drawing.Font("Script MT Bold", 28F, System.Drawing.FontStyle.Bold);
            this.SairBtn.Location = new System.Drawing.Point(535, 447);
            this.SairBtn.Name = "SairBtn";
            this.SairBtn.Size = new System.Drawing.Size(190, 79);
            this.SairBtn.TabIndex = 3;
            this.SairBtn.Text = "Sair";
            this.SairBtn.UseVisualStyleBackColor = true;
            this.SairBtn.Click += new System.EventHandler(this.SairBtn_Click);
            // 
            // LimparBtn
            // 
            this.LimparBtn.Font = new System.Drawing.Font("Script MT Bold", 28F, System.Drawing.FontStyle.Bold);
            this.LimparBtn.Location = new System.Drawing.Point(303, 447);
            this.LimparBtn.Name = "LimparBtn";
            this.LimparBtn.Size = new System.Drawing.Size(190, 79);
            this.LimparBtn.TabIndex = 4;
            this.LimparBtn.Text = "Limpar";
            this.LimparBtn.UseVisualStyleBackColor = true;
            this.LimparBtn.Click += new System.EventHandler(this.LimparBtn_Click);
            // 
            // VerificarBtn
            // 
            this.VerificarBtn.Font = new System.Drawing.Font("Script MT Bold", 28F, System.Drawing.FontStyle.Bold);
            this.VerificarBtn.Location = new System.Drawing.Point(62, 447);
            this.VerificarBtn.Name = "VerificarBtn";
            this.VerificarBtn.Size = new System.Drawing.Size(190, 79);
            this.VerificarBtn.TabIndex = 5;
            this.VerificarBtn.Text = "Verificar";
            this.VerificarBtn.UseVisualStyleBackColor = true;
            this.VerificarBtn.Click += new System.EventHandler(this.VerificarBtn_Click);
            // 
            // txtLadoC
            // 
            this.txtLadoC.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F);
            this.txtLadoC.Location = new System.Drawing.Point(303, 321);
            this.txtLadoC.Name = "txtLadoC";
            this.txtLadoC.Size = new System.Drawing.Size(422, 50);
            this.txtLadoC.TabIndex = 6;
            this.txtLadoC.Validating += new System.ComponentModel.CancelEventHandler(this.txtLadoC_Validating);
            
            // 
            // txtLadoB
            // 
            this.txtLadoB.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F);
            this.txtLadoB.Location = new System.Drawing.Point(303, 228);
            this.txtLadoB.Name = "txtLadoB";
            this.txtLadoB.Size = new System.Drawing.Size(422, 50);
            this.txtLadoB.TabIndex = 7;
            this.txtLadoB.Validating += new System.ComponentModel.CancelEventHandler(this.txtLadoB_Validating);
           
            // 
            // txtLadoA
            // 
            this.txtLadoA.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F);
            this.txtLadoA.Location = new System.Drawing.Point(303, 134);
            this.txtLadoA.Name = "txtLadoA";
            this.txtLadoA.Size = new System.Drawing.Size(422, 50);
            this.txtLadoA.TabIndex = 8;
            this.txtLadoA.Validating += new System.ComponentModel.CancelEventHandler(this.txtLadoA_Validating);
            
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 652);
            this.Controls.Add(this.txtLadoA);
            this.Controls.Add(this.txtLadoB);
            this.Controls.Add(this.txtLadoC);
            this.Controls.Add(this.VerificarBtn);
            this.Controls.Add(this.LimparBtn);
            this.Controls.Add(this.SairBtn);
            this.Controls.Add(this.LblLadoC);
            this.Controls.Add(this.LblLadoB);
            this.Controls.Add(this.LblLadoA);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblLadoA;
        private System.Windows.Forms.Label LblLadoB;
        private System.Windows.Forms.Label LblLadoC;
        private System.Windows.Forms.Button SairBtn;
        private System.Windows.Forms.Button LimparBtn;
        private System.Windows.Forms.Button VerificarBtn;
        private System.Windows.Forms.TextBox txtLadoC;
        private System.Windows.Forms.TextBox txtLadoB;
        private System.Windows.Forms.TextBox txtLadoA;
    }
}

