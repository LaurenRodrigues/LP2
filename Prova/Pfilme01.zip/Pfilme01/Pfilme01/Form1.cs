﻿using System;
using Microsoft.VisualBasic;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pfilme01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnExecutar_Click(object sender, EventArgs e)
        {
            
            double media, mediaf1, mediaf2;
            string[,] Filme = new string[3, 2];
            double[] notasf1 = new double[3];
            double[] notasf2 = new double[3];
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    string aux = Interaction.InputBox($"Por favor, insira a nota do filme{j + 1}", "Entrada das Notas");
                    Filme[i, j] = aux;
                    if (double.TryParse(aux, out media) && Convert.ToDouble(aux) < 10 && Convert.ToDouble(aux) > 0)
                    {
                        if (j == 0)
                        {
                            notasf1[i] = Convert.ToDouble(aux);
                            ListaNotasFilmes.Items.Add($"Pessoa {i + 1} Nota Filme 1: {Filme[i, j]}");
                           
                        }
                        else
                        {
                            notasf2[i] = Convert.ToDouble(aux);
                            ListaNotasFilmes.Items[i] += $" Nota Filme 2: {Filme[i,j]}";
                        }

                    }
                    else
                    {
                        MessageBox.Show("Valor inválido");
                        j--;
                    }
                   
                }
                
            }
            
            mediaf1 = (notasf1[0] + notasf1[1] + notasf1[2]) / 3;
            mediaf2 = (notasf2[0] + notasf2[1] + notasf2[2]) / 3;
            ListaNotasFilmes.Items.Add("------------------------------");
            ListaNotasFilmes.Items.Add($" Média filme 1: {mediaf1.ToString("n2")}");
            ListaNotasFilmes.Items.Add($" Média filme 2: {mediaf2.ToString("n2")}");
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            ListaNotasFilmes.Items.Clear();
        }
    }
}
