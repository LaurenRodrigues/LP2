﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Exercicio5 : Form
    {
        public Exercicio5()
        {
            InitializeComponent();
        }
        Char[,] gabarito = new Char[8, 10];
        char[,] Corretos = new char[2, 10];
        private void Exercicio5_Load(object sender, EventArgs e)
        {

            string aux = "";
            for (int n = 0; n < 2; n++)
            {
                for (int i = 0; i < 10; i++)
                {
                    aux = Interaction.InputBox($"Por favor, insira resposta {i+1} do aluno {n+1}", "Entrada de Dados");
                    if (aux.Length > 1 || aux == string.Empty || float.TryParse(aux,out float n2))
                    {

                        MessageBox.Show("Resposta inválida", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        i--; // Decrementa n para repetir a entrada
                        continue;
                    }
                    else
                    gabarito[n, i] = Convert.ToChar(aux.ToUpper());
                    Corretos[n, i] = 'A';
                    ListaNotas.Items.Add($"Aluno {n} marcou {gabarito[n, i]}");
                }
            }

        }

      

        private void BtnVerificar_Click_1(object sender, EventArgs e)
        {
            ListaNotas.Items.Clear();

            for (int n = 0; n < 2; n++)
            {
                for (int i = 0; i < 10; i++)
                {
                
                    if (gabarito[n, i] == Corretos[n, i])
                    {
                        ListaNotas.Items.Add($"Aluno {n} Acertou! marcou {gabarito[n, i]} era {Corretos[n, i]}");
                    }
                    else
                    {
                        ListaNotas.Items.Add($"Aluno {n} Errou! marcou {gabarito[n, i]} era {Corretos[n, i]}");
                    }
                }
            }
        }
    }
}
