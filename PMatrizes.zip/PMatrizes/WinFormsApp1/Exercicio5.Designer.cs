﻿namespace WinFormsApp1
{
    partial class Exercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BtnVerificar = new Button();
            ListaNotas = new ListBox();
            SuspendLayout();
            // 
            // BtnVerificar
            // 
            BtnVerificar.Location = new Point(141, 194);
            BtnVerificar.Name = "BtnVerificar";
            BtnVerificar.Size = new Size(75, 23);
            BtnVerificar.TabIndex = 3;
            BtnVerificar.Text = "button1";
            BtnVerificar.UseVisualStyleBackColor = true;
            BtnVerificar.Click += BtnVerificar_Click_1;
            // 
            // ListaNotas
            // 
            ListaNotas.FormattingEnabled = true;
            ListaNotas.ItemHeight = 15;
            ListaNotas.Location = new Point(421, 51);
            ListaNotas.Name = "ListaNotas";
            ListaNotas.Size = new Size(238, 349);
            ListaNotas.TabIndex = 2;
            // 
            // Exercicio5
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(BtnVerificar);
            Controls.Add(ListaNotas);
            Name = "Exercicio5";
            Text = "Exercicio5";
            Load += Exercicio5_Load;
            ResumeLayout(false);
        }

        #endregion

        private Button BtnVerificar;
        private ListBox ListaNotas;
    }
}