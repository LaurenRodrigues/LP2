﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Exercicio4 : Form
    {
        public Exercicio4()
        {
            InitializeComponent();
        }
        String[] Nomes = new String[10];
        private void Exercicio4_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < 10; i++)
            {
                Nomes[i] = Interaction.InputBox("Por favor, insira nome:", "Entrada de Dados");
                ListaNomes.Items.Add(Nomes[i]);
            }


        }

        private void BtnExecutar_Click(object sender, EventArgs e)
        {
            String aux = "";
            for (int i = 0;i < 10;i++)
            {
                aux = Nomes[i].Replace(" ", "");

                int n = aux.Length;
                aux = Convert.ToString(n) ;

                ListaNomes.Items[i] += $" Tem {aux} caracteres";
                
            }
        }
    }
}
