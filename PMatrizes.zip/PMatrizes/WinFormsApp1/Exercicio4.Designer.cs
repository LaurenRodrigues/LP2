﻿namespace WinFormsApp1
{
    partial class Exercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ListaNomes = new ListBox();
            BtnExecutar = new Button();
            SuspendLayout();
            // 
            // ListaNomes
            // 
            ListaNomes.FormattingEnabled = true;
            ListaNomes.ItemHeight = 15;
            ListaNomes.Location = new Point(506, 48);
            ListaNomes.Name = "ListaNomes";
            ListaNomes.Size = new Size(238, 349);
            ListaNomes.TabIndex = 0;
            // 
            // BtnExecutar
            // 
            BtnExecutar.Location = new Point(226, 191);
            BtnExecutar.Name = "BtnExecutar";
            BtnExecutar.Size = new Size(75, 23);
            BtnExecutar.TabIndex = 1;
            BtnExecutar.Text = "button1";
            BtnExecutar.UseVisualStyleBackColor = true;
            BtnExecutar.Click += BtnExecutar_Click;
            // 
            // Exercicio4
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(BtnExecutar);
            Controls.Add(ListaNomes);
            Name = "Exercicio4";
            Text = "Exercicio4";
            Load += Exercicio4_Load;
            ResumeLayout(false);
        }

        #endregion

        private ListBox ListaNomes;
        private Button BtnExecutar;
    }
}