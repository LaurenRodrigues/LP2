using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Runtime.Intrinsics.X86;
using System.Web;

namespace WinFormsApp1
{

    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }


        private void BtnExercicio1_Click(object sender, EventArgs e)
        {
            // cria o vetor que receber� os 20 n�meros
            int[] vetor = new int[20];

            // cria e inicializa uma vari�vel auxiliar
            string aux = "";

            // preenche o vetor usando inputbox como m�todo de entrada
            for (int i = 0; i < 20; i++)
            {
                aux = Interaction.InputBox("Por favor, insira n�mero:", "Entrada de Dados");
                if (int.TryParse(aux, out vetor[i]))
                {
                    // imprime o erro caso o valor nao seja conversivel para inteiro
                    MessageBox.Show("N�mero inv�lido", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }

            // inverte o vetor
            Array.Reverse(vetor);

            // reinicializa a variavel, jogando fora seu lixo
            aux = "";

            // grava na variavel aux�liar (string) os valores invertidos do vetor
            foreach (var i in vetor)
            {
                aux += i + "\n";
            }
            // imprime em uma message box o novo vetor
            MessageBox.Show(aux, "Vetor:", MessageBoxButtons.OK);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList
        {
            "Ana",
            "Andr�",
            "D�bora",
            "F�tima",
            "Jo�o",
            "Janete",
            "Ot�vio",
            "Marcelo",
            "Pedro",
            "Thais"
        };

            // Remove o aluno Ot�vio
            alunos.Remove("Ot�vio");

            // cria variavel aux�liar
            String aux = "";

            // grava na variavel auxiliar os alunos separados por um ",\n"
            for (int i = 0; i < alunos.Count; i++)
            {
                aux += alunos[i] + ",\n";
            }

            MessageBox.Show(aux, "Alunos restantes: ");

        }

        private void BtnExercicio3_Click(object sender, EventArgs e)
        {
            double[,] CalculoMedia = new double[20, 4]; // 3 notas + 1 m�dia

            string aux = "";
            double media, total;

            for (int i = 0; i < 20; i++)
            {
                total = 0; // Reinicia o total para cada aluno

                for (int n = 0; n < 3; n++)
                {
                    aux = Interaction.InputBox($"Por favor, insira a nota {n + 1} do aluno {i + 1}", "Entrada de Dados");

                    // Verifica se a convers�o para float foi bem-sucedida
                    if (!double.TryParse(aux, out media) || Convert.ToDouble(aux) > 10 || Convert.ToDouble(aux) < 0)
                    {
                        // Imprime o erro caso o valor n�o seja convers�vel para float
                        MessageBox.Show("N�mero inv�lido", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        n--; // Decrementa n para repetir a entrada
                        continue; // Continua para a pr�xima itera��o
                    }

                    total += media; // Acumula as notas
                }

                // Calcula a m�dia ap�s as 3 notas
                CalculoMedia[i, 3] = total / 3; // Armazena a m�dia na quarta coluna
            }
            for (int i = 0; i < 20; i++)
            {
                aux += $" M�dia Aluno {i + 1}:" + CalculoMedia[i, 3].ToString("n2") + "\n";
            }
            MessageBox.Show(aux, " Resultado ");
        }


        private void BtnExercicio4_Click(object sender, EventArgs e)
        {   
            
            Exercicio4 form4 = new Exercicio4(); // Cria uma inst�ncia do Form4
            form4.Show();
        }

        private void BtnExercicio5_Click(object sender, EventArgs e)
        {
            Exercicio5 form5 = new Exercicio5(); // Cria uma inst�ncia do Form5
            form5.Show();
        }
    }

}
