﻿using Microsoft.VisualBasic;
namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BtnExercicio1 = new Button();
            BtnExercicio2 = new Button();
            BtnExercicio3 = new Button();
            BtnExercicio4 = new Button();
            BtnExercicio5 = new Button();
            SuspendLayout();
            // 
            // BtnExercicio1
            // 
            BtnExercicio1.Location = new Point(171, 156);
            BtnExercicio1.Name = "BtnExercicio1";
            BtnExercicio1.Size = new Size(75, 23);
            BtnExercicio1.TabIndex = 0;
            BtnExercicio1.Text = "Exercicio1";
            BtnExercicio1.UseVisualStyleBackColor = true;
            BtnExercicio1.Click += BtnExercicio1_Click;
            // 
            // BtnExercicio2
            // 
            BtnExercicio2.Location = new Point(512, 156);
            BtnExercicio2.Name = "BtnExercicio2";
            BtnExercicio2.Size = new Size(75, 23);
            BtnExercicio2.TabIndex = 1;
            BtnExercicio2.Text = "Exercicio2";
            BtnExercicio2.UseVisualStyleBackColor = true;
            BtnExercicio2.Click += button2_Click;
            // 
            // BtnExercicio3
            // 
            BtnExercicio3.Location = new Point(171, 266);
            BtnExercicio3.Name = "BtnExercicio3";
            BtnExercicio3.Size = new Size(75, 23);
            BtnExercicio3.TabIndex = 2;
            BtnExercicio3.Text = "Exercicio3";
            BtnExercicio3.UseVisualStyleBackColor = true;
            BtnExercicio3.Click += BtnExercicio3_Click;
            // 
            // BtnExercicio4
            // 
            BtnExercicio4.Location = new Point(512, 266);
            BtnExercicio4.Name = "BtnExercicio4";
            BtnExercicio4.Size = new Size(75, 23);
            BtnExercicio4.TabIndex = 3;
            BtnExercicio4.Text = "Exercicio4";
            BtnExercicio4.UseVisualStyleBackColor = true;
            BtnExercicio4.Click += BtnExercicio4_Click;
            // 
            // BtnExercicio5
            // 
            BtnExercicio5.Location = new Point(345, 314);
            BtnExercicio5.Name = "BtnExercicio5";
            BtnExercicio5.Size = new Size(75, 23);
            BtnExercicio5.TabIndex = 4;
            BtnExercicio5.Text = "Exercicio5";
            BtnExercicio5.UseVisualStyleBackColor = true;
            BtnExercicio5.Click += BtnExercicio5_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(BtnExercicio5);
            Controls.Add(BtnExercicio4);
            Controls.Add(BtnExercicio3);
            Controls.Add(BtnExercicio2);
            Controls.Add(BtnExercicio1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button BtnExercicio1;
        private Button BtnExercicio2;
        private Button BtnExercicio3;
        private Button BtnExercicio4;
        private Button BtnExercicio5;
    }
}
