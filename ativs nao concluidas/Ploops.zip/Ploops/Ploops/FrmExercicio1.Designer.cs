﻿namespace Ploops
{
    partial class FrmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RichTextBoxEx1 = new System.Windows.Forms.RichTextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // RichTextBoxEx1
            // 
            this.RichTextBoxEx1.BackColor = System.Drawing.SystemColors.Window;
            this.RichTextBoxEx1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.RichTextBoxEx1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.RichTextBoxEx1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(121)))), ((int)(((byte)(141)))));
            this.RichTextBoxEx1.Location = new System.Drawing.Point(140, 195);
            this.RichTextBoxEx1.MaxLength = 100;
            this.RichTextBoxEx1.Name = "RichTextBoxEx1";
            this.RichTextBoxEx1.Size = new System.Drawing.Size(619, 96);
            this.RichTextBoxEx1.TabIndex = 0;
            this.RichTextBoxEx1.Text = "";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(244)))), ((int)(((byte)(214)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Lucida Calligraphy", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(121)))), ((int)(((byte)(141)))));
            this.button1.Location = new System.Drawing.Point(61, 405);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(176, 110);
            this.button1.TabIndex = 1;
            this.button1.Text = "Qntde Espaços em Branco";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(244)))), ((int)(((byte)(214)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Lucida Calligraphy", 15.75F);
            this.button2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(121)))), ((int)(((byte)(141)))));
            this.button2.Location = new System.Drawing.Point(695, 405);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(176, 110);
            this.button2.TabIndex = 2;
            this.button2.Text = "Qntde pares";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(244)))), ((int)(((byte)(214)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Lucida Calligraphy", 15.75F);
            this.button3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(121)))), ((int)(((byte)(141)))));
            this.button3.Location = new System.Drawing.Point(360, 405);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(176, 110);
            this.button3.TabIndex = 3;
            this.button3.Text = "Qntde \"r\"";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // FrmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(189)))), ((int)(((byte)(192)))));
            this.BackgroundImage = global::Ploops.Properties.Resources.Sem_título1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(917, 622);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.RichTextBoxEx1);
            this.Name = "FrmExercicio1";
            this.Text = "FrmExercicio1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox RichTextBoxEx1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}