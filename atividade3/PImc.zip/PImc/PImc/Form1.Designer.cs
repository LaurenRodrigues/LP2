﻿namespace PImc
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.TxtIMC = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Calcular = new System.Windows.Forms.Button();
            this.MskdTxtPeso = new System.Windows.Forms.MaskedTextBox();
            this.MskdTxtAltura = new System.Windows.Forms.MaskedTextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TxtIMC
            // 
            this.TxtIMC.Enabled = false;
            this.TxtIMC.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F);
            this.TxtIMC.Location = new System.Drawing.Point(278, 262);
            this.TxtIMC.Name = "TxtIMC";
            this.TxtIMC.Size = new System.Drawing.Size(143, 50);
            this.TxtIMC.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label1.Font = new System.Drawing.Font("Script MT Bold", 27.75F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.label1.Location = new System.Drawing.Point(155, 265);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 44);
            this.label1.TabIndex = 3;
            this.label1.Text = "Imc";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label2.Font = new System.Drawing.Font("Script MT Bold", 27.75F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.label2.Location = new System.Drawing.Point(117, 149);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 44);
            this.label2.TabIndex = 4;
            this.label2.Text = "Altura";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label3.Font = new System.Drawing.Font("Script MT Bold", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.label3.Location = new System.Drawing.Point(34, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(183, 44);
            this.label3.TabIndex = 5;
            this.label3.Text = "Peso Atual";
            // 
            // Calcular
            // 
            this.Calcular.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.Calcular.Font = new System.Drawing.Font("Script MT Bold", 27.75F, System.Drawing.FontStyle.Bold);
            this.Calcular.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Calcular.Location = new System.Drawing.Point(152, 364);
            this.Calcular.Name = "Calcular";
            this.Calcular.Size = new System.Drawing.Size(209, 82);
            this.Calcular.TabIndex = 6;
            this.Calcular.Text = "Calcular";
            this.Calcular.UseVisualStyleBackColor = false;
            this.Calcular.Click += new System.EventHandler(this.Calcular_Click);
            // 
            // MskdTxtPeso
            // 
            this.MskdTxtPeso.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F);
            this.MskdTxtPeso.Location = new System.Drawing.Point(278, 32);
            this.MskdTxtPeso.Mask = "900.00";
            this.MskdTxtPeso.Name = "MskdTxtPeso";
            this.MskdTxtPeso.Size = new System.Drawing.Size(143, 50);
            this.MskdTxtPeso.TabIndex = 7;
            this.MskdTxtPeso.Validated += new System.EventHandler(this.MskdTxtPeso_Validated);
            // 
            // MskdTxtAltura
            // 
            this.MskdTxtAltura.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F);
            this.MskdTxtAltura.Location = new System.Drawing.Point(278, 146);
            this.MskdTxtAltura.Mask = "0.00";
            this.MskdTxtAltura.Name = "MskdTxtAltura";
            this.MskdTxtAltura.Size = new System.Drawing.Size(143, 50);
            this.MskdTxtAltura.TabIndex = 8;
            this.MskdTxtAltura.Validated += new System.EventHandler(this.MskdTxtAltura_Validated);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.button1.Font = new System.Drawing.Font("Script MT Bold", 27.75F, System.Drawing.FontStyle.Bold);
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button1.Location = new System.Drawing.Point(42, 467);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(209, 82);
            this.button1.TabIndex = 9;
            this.button1.Text = "Limpar";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.button2.Font = new System.Drawing.Font("Script MT Bold", 27.75F, System.Drawing.FontStyle.Bold);
            this.button2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button2.Location = new System.Drawing.Point(278, 467);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(209, 82);
            this.button2.TabIndex = 10;
            this.button2.Text = "Sair";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PImc.Properties.Resources.d88351eef225045f95cecbc25a119aaf;
            this.ClientSize = new System.Drawing.Size(538, 628);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.MskdTxtAltura);
            this.Controls.Add(this.MskdTxtPeso);
            this.Controls.Add(this.Calcular);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TxtIMC);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TxtIMC;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button Calcular;
        private System.Windows.Forms.MaskedTextBox MskdTxtPeso;
        private System.Windows.Forms.MaskedTextBox MskdTxtAltura;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}

